<?php

/* No Changes */
/* Leeper */
/* you can removes these notes */

$component = new OssnComponents;
$settings  = $component->getSettings('RssFeed');
$url = "$settings->rss_html";
        
$invalidurl = false;
        if(@simplexml_load_file($url)){
            $feeds = simplexml_load_file($url);
        }else{
            $invalidurl = true;
            echo "<div class='widget-heading'>Invalid RSS feed URL</div>";
        }


        $i=0;
        if(!empty($feeds)){


            $site = $feeds->channel->title;
            $sitelink = $feeds->channel->link;

            echo "<div class='widget-heading'>".$site."</div>";
            foreach ($feeds->channel->item as $item) {

                $title = $item->title;
                $link = $item->link;
                $description = $item->description;
                $postDate = $item->pubDate;
                $pubDate = date('D, d M Y',strtotime($postDate));


                if($i>=5) break;// Ammount of news to show! Default value="5"
        ?>
		<div class="widget-contents">
				<span class="time-created"><?php echo $pubDate; ?></span>
	<h5><a href="<?php echo $link; ?>"><?php echo $title; ?></a></h5>
<?php echo implode(' ', array_slice(explode(' ', $description), 0, 20)) . "..."; // How many characters to show on preview. Default value="20"
	?> <a href="<?php echo $link; ?>"><?php echo ossn_print('com_rssfeed:readmore'); ?></a>
			</div>
        <?php
                $i++;
            }
        }else{
            if(!$invalidurl){
                echo "<h3>No items found</h3>";
            }
        }
    ?>

